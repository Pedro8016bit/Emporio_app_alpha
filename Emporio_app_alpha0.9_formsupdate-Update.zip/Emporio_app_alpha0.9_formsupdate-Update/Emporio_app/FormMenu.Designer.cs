﻿using System.ComponentModel;

namespace Emporio_app;

partial class FormMenu
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
        btnVoltar = new System.Windows.Forms.Button();
        button1 = new System.Windows.Forms.Button();
        button2 = new System.Windows.Forms.Button();
        button3 = new System.Windows.Forms.Button();
        button4 = new System.Windows.Forms.Button();
        pictureBox1 = new System.Windows.Forms.PictureBox();
        pictureBox2 = new System.Windows.Forms.PictureBox();
        pictureBox3 = new System.Windows.Forms.PictureBox();
        pictureBox4 = new System.Windows.Forms.PictureBox();
        pictureBox5 = new System.Windows.Forms.PictureBox();
        pictureBox6 = new System.Windows.Forms.PictureBox();
        pictureBox7 = new System.Windows.Forms.PictureBox();
        label1 = new System.Windows.Forms.Label();
        label2 = new System.Windows.Forms.Label();
        label3 = new System.Windows.Forms.Label();
        ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
        SuspendLayout();
        // 
        // btnVoltar
        // 
        btnVoltar.Location = new System.Drawing.Point(718, 411);
        btnVoltar.Name = "btnVoltar";
        btnVoltar.Size = new System.Drawing.Size(80, 37);
        btnVoltar.TabIndex = 0;
        btnVoltar.Text = "Voltar";
        btnVoltar.UseVisualStyleBackColor = true;
        btnVoltar.Click += btnVoltar_Click_1;
        // 
        // button1
        // 
        button1.BackgroundImage = ((System.Drawing.Image)resources.GetObject("button1.BackgroundImage"));
        button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
        button1.Location = new System.Drawing.Point(378, 225);
        button1.Name = "button1";
        button1.Size = new System.Drawing.Size(70, 60);
        button1.TabIndex = 1;
        button1.UseVisualStyleBackColor = true;
        // 
        // button2
        // 
        button2.BackgroundImage = ((System.Drawing.Image)resources.GetObject("button2.BackgroundImage"));
        button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        button2.Location = new System.Drawing.Point(231, 225);
        button2.Name = "button2";
        button2.Size = new System.Drawing.Size(70, 60);
        button2.TabIndex = 2;
        button2.UseVisualStyleBackColor = true;
        button2.Click += button2_Click;
        // 
        // button3
        // 
        button3.BackgroundImage = ((System.Drawing.Image)resources.GetObject("button3.BackgroundImage"));
        button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
        button3.Location = new System.Drawing.Point(-100, 325);
        button3.Name = "button3";
        button3.Size = new System.Drawing.Size(0, 0);
        button3.TabIndex = 3;
        button3.UseVisualStyleBackColor = true;
        // 
        // button4
        // 
        button4.BackgroundImage = ((System.Drawing.Image)resources.GetObject("button4.BackgroundImage"));
        button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
        button4.Location = new System.Drawing.Point(513, 225);
        button4.Name = "button4";
        button4.Size = new System.Drawing.Size(70, 60);
        button4.TabIndex = 4;
        button4.UseVisualStyleBackColor = true;
        // 
        // pictureBox1
        // 
        pictureBox1.Image = ((System.Drawing.Image)resources.GetObject("pictureBox1.Image"));
        pictureBox1.Location = new System.Drawing.Point(-33, 380);
        pictureBox1.Name = "pictureBox1";
        pictureBox1.Size = new System.Drawing.Size(200, 150);
        pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox1.TabIndex = 5;
        pictureBox1.TabStop = false;
        // 
        // pictureBox2
        // 
        pictureBox2.Image = ((System.Drawing.Image)resources.GetObject("pictureBox2.Image"));
        pictureBox2.Location = new System.Drawing.Point(728, -6);
        pictureBox2.Name = "pictureBox2";
        pictureBox2.Size = new System.Drawing.Size(100, 50);
        pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox2.TabIndex = 6;
        pictureBox2.TabStop = false;
        // 
        // pictureBox3
        // 
        pictureBox3.Image = ((System.Drawing.Image)resources.GetObject("pictureBox3.Image"));
        pictureBox3.Location = new System.Drawing.Point(746, 355);
        pictureBox3.Name = "pictureBox3";
        pictureBox3.Size = new System.Drawing.Size(100, 50);
        pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox3.TabIndex = 7;
        pictureBox3.TabStop = false;
        // 
        // pictureBox4
        // 
        pictureBox4.Image = ((System.Drawing.Image)resources.GetObject("pictureBox4.Image"));
        pictureBox4.Location = new System.Drawing.Point(188, 176);
        pictureBox4.Name = "pictureBox4";
        pictureBox4.Size = new System.Drawing.Size(100, 50);
        pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox4.TabIndex = 8;
        pictureBox4.TabStop = false;
        // 
        // pictureBox5
        // 
        pictureBox5.Image = ((System.Drawing.Image)resources.GetObject("pictureBox5.Image"));
        pictureBox5.Location = new System.Drawing.Point(-33, -6);
        pictureBox5.Name = "pictureBox5";
        pictureBox5.Size = new System.Drawing.Size(130, 80);
        pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox5.TabIndex = 9;
        pictureBox5.TabStop = false;
        // 
        // pictureBox6
        // 
        pictureBox6.Image = ((System.Drawing.Image)resources.GetObject("pictureBox6.Image"));
        pictureBox6.Location = new System.Drawing.Point(443, 314);
        pictureBox6.MaximumSize = new System.Drawing.Size(100, 50);
        pictureBox6.Name = "pictureBox6";
        pictureBox6.Size = new System.Drawing.Size(100, 50);
        pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox6.TabIndex = 10;
        pictureBox6.TabStop = false;
        // 
        // pictureBox7
        // 
        pictureBox7.Image = ((System.Drawing.Image)resources.GetObject("pictureBox7.Image"));
        pictureBox7.Location = new System.Drawing.Point(334, 119);
        pictureBox7.Name = "pictureBox7";
        pictureBox7.Size = new System.Drawing.Size(150, 100);
        pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox7.TabIndex = 11;
        pictureBox7.TabStop = false;
        // 
        // label1
        // 
        label1.BackColor = System.Drawing.SystemColors.Control;
        label1.Location = new System.Drawing.Point(213, 288);
        label1.Name = "label1";
        label1.Size = new System.Drawing.Size(108, 23);
        label1.TabIndex = 12;
        label1.Text = "Gerenciar Produtos";
        // 
        // label2
        // 
        label2.BackColor = System.Drawing.SystemColors.Control;
        label2.Location = new System.Drawing.Point(393, 288);
        label2.Name = "label2";
        label2.Size = new System.Drawing.Size(44, 23);
        label2.TabIndex = 13;
        label2.Text = "Vendas";
        // 
        // label3
        // 
        label3.BackColor = System.Drawing.SystemColors.Control;
        label3.Location = new System.Drawing.Point(495, 288);
        label3.Name = "label3";
        label3.Size = new System.Drawing.Size(111, 23);
        label3.TabIndex = 14;
        label3.Text = "Historico de vendas";
        // 
        // Menu
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(800, 450);
        Controls.Add(label3);
        Controls.Add(label2);
        Controls.Add(label1);
        Controls.Add(pictureBox7);
        Controls.Add(pictureBox6);
        Controls.Add(pictureBox5);
        Controls.Add(pictureBox4);
        Controls.Add(pictureBox3);
        Controls.Add(pictureBox2);
        Controls.Add(pictureBox1);
        Controls.Add(button4);
        Controls.Add(button3);
        Controls.Add(button2);
        Controls.Add(button1);
        Controls.Add(btnVoltar);
        Name = "Menu";
        Text = "Menu";
        ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
        ResumeLayout(false);
    }

    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;

    private System.Windows.Forms.Label label1;

    private System.Windows.Forms.PictureBox pictureBox7;

    private System.Windows.Forms.PictureBox pictureBox6;

    private System.Windows.Forms.PictureBox pictureBox5;

    private System.Windows.Forms.PictureBox pictureBox4;

    private System.Windows.Forms.PictureBox pictureBox3;

    private System.Windows.Forms.PictureBox pictureBox2;

    private System.Windows.Forms.PictureBox pictureBox1;

    private System.Windows.Forms.Button button4;

    private System.Windows.Forms.Button button3;

    private System.Windows.Forms.Button button2;

    private System.Windows.Forms.Button button1;

    private System.Windows.Forms.Button btnVoltar;

    #endregion
}