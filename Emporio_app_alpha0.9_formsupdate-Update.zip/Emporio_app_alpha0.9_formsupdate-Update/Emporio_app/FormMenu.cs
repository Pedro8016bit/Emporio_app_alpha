﻿namespace Emporio_app;

public partial class FormMenu : Form
{
    public FormMenu()
    {
        InitializeComponent();
    }

    private void btnVoltar_Click_1(object sender, EventArgs e)
    {
        Form1 primeiroFormulario = new Form1();
        primeiroFormulario.Show();
        this.Close();
    }



    private void button2_Click(object sender, EventArgs e)
    {
        area_Produto areaProduto = new area_Produto();
        areaProduto.Show();
        this.Close();
    }

}
