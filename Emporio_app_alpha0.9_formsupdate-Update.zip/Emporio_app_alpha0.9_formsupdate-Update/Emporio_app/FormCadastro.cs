namespace Emporio_app;

public partial class FormCadastro : Form
{
    public FormCadastro()
    {
        InitializeComponent();
    }
}