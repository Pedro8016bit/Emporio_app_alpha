namespace Emporio_app;

public partial class area_Produto : Form
{
    public int cod = 0;
    public area_Produto()
    {
        InitializeComponent();
        //listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;

    }

    private void btn_Home_Click(object sender, EventArgs e)
    {
        FormMenu tela_menu = new FormMenu();
        tela_menu.Show();
        this.Close();
    }
    

    private void btn_Pesquisar_item_Click(object sender, EventArgs e)
    {
        
    }

    private void listView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (listView1.SelectedItems.Count > 0) // Verifica se há um item selecionado
        {
            ListViewItem itemSelecionado = listView1.SelectedItems[0]; // Obtém o item selecionado

            // Exibe informações do item selecionado (opcional)
            string id = itemSelecionado.SubItems[0].Text;
            string nome = itemSelecionado.SubItems[1].Text;
            string preco = itemSelecionado.SubItems[2].Text;
            string tamanho = itemSelecionado.SubItems[3].Text;
            string quantidade = itemSelecionado.SubItems[4].Text;

            DialogResult resultado = MessageBox.Show($"Tem certeza que deseja excluir o item?\n\nID: {id}\nNome: {nome}",
                "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (resultado == DialogResult.Yes) 
            {
                listView1.Items.Remove(itemSelecionado); // Remove o item da ListView
            }
        }
        else
        {
            MessageBox.Show("Selecione um item antes de excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }

    
    

    private void btn_Cadastrar_item_Click(object sender, EventArgs e)
    {
        this.cod = this.cod + 1;
        System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem(new string[] {Convert.ToString(this.cod), txb_Name_item.Text, nUD_Preço_item.Text, nUD_Tamanho_item.Text, nUD_Quantidade_item.Text}, -1);
        listView1.Items.Add(listViewItem1);
        
    }

    private void btn_Exclui_item_Click(object sender, EventArgs e)
    {
        if (listView1.SelectedItems.Count > 0)
        {
            ListViewItem itemSelecionado = listView1.SelectedItems[0];

            string id = itemSelecionado.SubItems[0].Text;
            string nome = itemSelecionado.SubItems[1].Text;

            DialogResult resultado = MessageBox.Show($"Tem certeza que deseja excluir o item?\n\nID: {id}\nNome: {nome}",
                "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (resultado == DialogResult.Yes)
            {
                listView1.Items.Remove(itemSelecionado);

            }
        }
        else
        {
            MessageBox.Show("Selecione um item antes de excluir.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }


    private void btn_Editar_item_Click(object sender, EventArgs e)
    {
        if (listView1.SelectedItems.Count > 0)
        {
            ListViewItem itemSelecionado = listView1.SelectedItems[0];
            FormEdit form_edit = new FormEdit(itemSelecionado); 
            form_edit.Show();
        }
        else
        {
            MessageBox.Show("Selecione um item antes de editar.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        
        
        
    }
}