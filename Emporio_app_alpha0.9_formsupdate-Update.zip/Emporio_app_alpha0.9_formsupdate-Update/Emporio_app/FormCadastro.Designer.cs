using System.ComponentModel;

namespace Emporio_app;

partial class FormCadastro
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        bt_cancelar = new System.Windows.Forms.Button();
        bt_salvar = new System.Windows.Forms.Button();
        lb_nome = new System.Windows.Forms.Label();
        textBox1 = new System.Windows.Forms.TextBox();
        textBox2 = new System.Windows.Forms.TextBox();
        lb_Quantidade = new System.Windows.Forms.Label();
        textBox3 = new System.Windows.Forms.TextBox();
        lb_preco = new System.Windows.Forms.Label();
        textBox4 = new System.Windows.Forms.TextBox();
        lb_Tamanho = new System.Windows.Forms.Label();
        SuspendLayout();
        // 
        // bt_cancelar
        // 
        bt_cancelar.Location = new System.Drawing.Point(171, 371);
        bt_cancelar.Name = "bt_cancelar";
        bt_cancelar.Size = new System.Drawing.Size(75, 23);
        bt_cancelar.TabIndex = 0;
        bt_cancelar.Text = "cancelar";
        bt_cancelar.UseVisualStyleBackColor = true;
        // 
        // bt_salvar
        // 
        bt_salvar.Location = new System.Drawing.Point(22, 371);
        bt_salvar.Name = "bt_salvar";
        bt_salvar.Size = new System.Drawing.Size(75, 23);
        bt_salvar.TabIndex = 1;
        bt_salvar.Text = "salvar";
        bt_salvar.UseVisualStyleBackColor = true;
        // 
        // lb_nome
        // 
        lb_nome.Location = new System.Drawing.Point(70, 52);
        lb_nome.Name = "lb_nome";
        lb_nome.Size = new System.Drawing.Size(100, 23);
        lb_nome.TabIndex = 2;
        lb_nome.Text = "nome";
        // 
        // textBox1
        // 
        textBox1.Location = new System.Drawing.Point(70, 78);
        textBox1.Name = "textBox1";
        textBox1.Size = new System.Drawing.Size(100, 23);
        textBox1.TabIndex = 3;
        // 
        // textBox2
        // 
        textBox2.Location = new System.Drawing.Point(70, 226);
        textBox2.Name = "textBox2";
        textBox2.Size = new System.Drawing.Size(100, 23);
        textBox2.TabIndex = 5;
        // 
        // lb_Quantidade
        // 
        lb_Quantidade.Location = new System.Drawing.Point(70, 200);
        lb_Quantidade.Name = "lb_Quantidade";
        lb_Quantidade.Size = new System.Drawing.Size(100, 23);
        lb_Quantidade.TabIndex = 4;
        lb_Quantidade.Text = "quantidade";
        // 
        // textBox3
        // 
        textBox3.Location = new System.Drawing.Point(70, 295);
        textBox3.Name = "textBox3";
        textBox3.Size = new System.Drawing.Size(100, 23);
        textBox3.TabIndex = 7;
        // 
        // lb_preco
        // 
        lb_preco.Location = new System.Drawing.Point(70, 269);
        lb_preco.Name = "lb_preco";
        lb_preco.Size = new System.Drawing.Size(100, 23);
        lb_preco.TabIndex = 6;
        lb_preco.Text = "preco";
        // 
        // textBox4
        // 
        textBox4.Location = new System.Drawing.Point(70, 155);
        textBox4.Name = "textBox4";
        textBox4.Size = new System.Drawing.Size(100, 23);
        textBox4.TabIndex = 9;
        // 
        // lb_Tamanho
        // 
        lb_Tamanho.Location = new System.Drawing.Point(70, 129);
        lb_Tamanho.Name = "lb_Tamanho";
        lb_Tamanho.Size = new System.Drawing.Size(100, 23);
        lb_Tamanho.TabIndex = 8;
        lb_Tamanho.Text = "tamanho";
        // 
        // FormCadastro
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(284, 447);
        Controls.Add(textBox4);
        Controls.Add(lb_Tamanho);
        Controls.Add(textBox3);
        Controls.Add(lb_preco);
        Controls.Add(textBox2);
        Controls.Add(lb_Quantidade);
        Controls.Add(textBox1);
        Controls.Add(lb_nome);
        Controls.Add(bt_salvar);
        Controls.Add(bt_cancelar);
        Text = "FormCadastro";
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.Button bt_cancelar;
    private System.Windows.Forms.Button bt_salvar;
    private System.Windows.Forms.Label lb_nome;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.Label lb_Quantidade;
    private System.Windows.Forms.TextBox textBox3;
    private System.Windows.Forms.Label lb_preco;
    private System.Windows.Forms.TextBox textBox4;
    private System.Windows.Forms.Label lb_Tamanho;

    #endregion
}