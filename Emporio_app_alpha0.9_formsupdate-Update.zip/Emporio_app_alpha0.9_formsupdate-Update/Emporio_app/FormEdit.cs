namespace Emporio_app;

public partial class FormEdit : Form
{
    private  ListViewItem itemSelecionado;
    
    
    public FormEdit(ListViewItem itemSelecionado)
    {
        InitializeComponent();
        this.itemSelecionado = itemSelecionado;
        tb_nome.Text = itemSelecionado.SubItems[1].Text;
        tb_preco.Text = itemSelecionado.SubItems[2].Text;
        tb_quantidade.Text = itemSelecionado.SubItems[3].Text;
        tb_tamanho.Text = itemSelecionado.SubItems[4].Text;
    }

    private void bt_cancelar_Click(object sender, EventArgs e)
    {
       this.Close();
    }

    private void Salvar_Click(object sender, EventArgs e)
    {

        string id = itemSelecionado.SubItems[0].Text;
        string nome = itemSelecionado.SubItems[1].Text;

        DialogResult resultado = MessageBox.Show($"Tem certeza que deseja Editar o item?\n\nID: {id}\nNome: {nome}",
            "Confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

        if (resultado == DialogResult.Yes)
        {
           

        }
    }
}