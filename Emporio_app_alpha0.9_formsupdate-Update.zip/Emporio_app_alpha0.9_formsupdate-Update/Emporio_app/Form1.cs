namespace Emporio_app;

public partial class Form1 : Form
{
    private List<Usuario> usuarios = new List<Usuario>();

    public Form1()
    {
        InitializeComponent();
    }
    
    private void escreve_login_TextChanged(object sender, EventArgs e)
    {
        escreve_login.Text = escreve_login.Text.Trim();
    }

    private void escreve_senha_TextChanged(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(escreve_senha.Text))
        {
            MessageBox.Show("A senha não pode estar vazia!");
        }
    }

    private void btn_Acesso_Click(object sender, EventArgs e)
    {
        string nome = escreve_login.Text;
        string senha = escreve_senha.Text;

        var usuarioEncontrado = usuarios.Find(u => u.Nome == nome && u.Senha == senha);

        if (usuarioEncontrado != null)
        {
            FormMenu segundoFormulario = new FormMenu();
            segundoFormulario.Show();
            this.Hide();
        }
        else
        {
            MessageBox.Show("Usuário ou senha incorretos!");
        }
    }

    private void btn_cad_Click(object sender, EventArgs e)
    {
        string nome = escreve_login.Text;
        string senha = escreve_senha.Text;

        if (!string.IsNullOrWhiteSpace(nome) && !string.IsNullOrWhiteSpace(senha))
        {
            usuarios.Add(new Usuario(nome, senha));
            MessageBox.Show("Usuário cadastrado com sucesso!");
        }
        else
        {
            MessageBox.Show("Preencha todos os campos!");
        }
    }

    private void Login_text_Click(object sender, EventArgs e)
    {
        // Pode ser deixado vazio ou implementar algo se necessário
    }

    private void senha_text_Click(object sender, EventArgs e)
    {
        // Pode ser deixado vazio ou implementar algo se necessário
    }

}
