using System.ComponentModel;

namespace Emporio_app;

partial class FormEdit
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        tb_nome = new System.Windows.Forms.TextBox();
        lb_nome = new System.Windows.Forms.Label();
        lb_preco = new System.Windows.Forms.Label();
        tb_preco = new System.Windows.Forms.TextBox();
        lb_quantidade = new System.Windows.Forms.Label();
        tb_quantidade = new System.Windows.Forms.TextBox();
        lb_tamanho = new System.Windows.Forms.Label();
        tb_tamanho = new System.Windows.Forms.TextBox();
        Salvar = new System.Windows.Forms.Button();
        bt_cancelar = new System.Windows.Forms.Button();
        SuspendLayout();
        // 
        // tb_nome
        // 
        tb_nome.Location = new System.Drawing.Point(69, 110);
        tb_nome.Name = "tb_nome";
        tb_nome.Size = new System.Drawing.Size(152, 23);
        tb_nome.TabIndex = 0;
        // 
        // lb_nome
        // 
        lb_nome.Location = new System.Drawing.Point(69, 84);
        lb_nome.Name = "lb_nome";
        lb_nome.Size = new System.Drawing.Size(100, 23);
        lb_nome.TabIndex = 4;
        lb_nome.Text = "Nome";
        // 
        // lb_preco
        // 
        lb_preco.Location = new System.Drawing.Point(69, 297);
        lb_preco.Name = "lb_preco";
        lb_preco.Size = new System.Drawing.Size(100, 23);
        lb_preco.TabIndex = 6;
        lb_preco.Text = "Preço";
        // 
        // tb_preco
        // 
        tb_preco.Location = new System.Drawing.Point(69, 323);
        tb_preco.Name = "tb_preco";
        tb_preco.Size = new System.Drawing.Size(152, 23);
        tb_preco.TabIndex = 5;
        // 
        // lb_quantidade
        // 
        lb_quantidade.Location = new System.Drawing.Point(69, 153);
        lb_quantidade.Name = "lb_quantidade";
        lb_quantidade.Size = new System.Drawing.Size(100, 23);
        lb_quantidade.TabIndex = 8;
        lb_quantidade.Text = "Quantidade";
        // 
        // tb_quantidade
        // 
        tb_quantidade.Location = new System.Drawing.Point(69, 179);
        tb_quantidade.Name = "tb_quantidade";
        tb_quantidade.Size = new System.Drawing.Size(152, 23);
        tb_quantidade.TabIndex = 7;
        // 
        // lb_tamanho
        // 
        lb_tamanho.Location = new System.Drawing.Point(69, 226);
        lb_tamanho.Name = "lb_tamanho";
        lb_tamanho.Size = new System.Drawing.Size(100, 23);
        lb_tamanho.TabIndex = 10;
        lb_tamanho.Text = "Tamanho";
        // 
        // tb_tamanho
        // 
        tb_tamanho.Location = new System.Drawing.Point(69, 252);
        tb_tamanho.Name = "tb_tamanho";
        tb_tamanho.Size = new System.Drawing.Size(152, 23);
        tb_tamanho.TabIndex = 9;
        // 
        // Salvar
        // 
        Salvar.Location = new System.Drawing.Point(180, 384);
        Salvar.Name = "Salvar";
        Salvar.Size = new System.Drawing.Size(75, 23);
        Salvar.TabIndex = 11;
        Salvar.Text = "Salvar";
        Salvar.UseVisualStyleBackColor = true;
        Salvar.Click += Salvar_Click;
        // 
        // bt_cancelar
        // 
        bt_cancelar.Location = new System.Drawing.Point(38, 384);
        bt_cancelar.Name = "bt_cancelar";
        bt_cancelar.Size = new System.Drawing.Size(75, 23);
        bt_cancelar.TabIndex = 12;
        bt_cancelar.Text = "Cancelar";
        bt_cancelar.UseVisualStyleBackColor = true;
        bt_cancelar.Click += bt_cancelar_Click;
        // 
        // FormEdit
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(291, 459);
        Controls.Add(bt_cancelar);
        Controls.Add(Salvar);
        Controls.Add(lb_tamanho);
        Controls.Add(tb_tamanho);
        Controls.Add(lb_quantidade);
        Controls.Add(tb_quantidade);
        Controls.Add(lb_preco);
        Controls.Add(tb_preco);
        Controls.Add(lb_nome);
        Controls.Add(tb_nome);
        Text = "Editar Produto";
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.Button Salvar;
    private System.Windows.Forms.Button bt_cancelar;

    private System.Windows.Forms.TextBox tb_nome;
    private System.Windows.Forms.TextBox tb_preco;
    private System.Windows.Forms.TextBox tb_quantidade;
    private System.Windows.Forms.TextBox tb_tamanho;
    private System.Windows.Forms.Label lb_nome;
    private System.Windows.Forms.Label lb_preco;
    private System.Windows.Forms.Label lb_quantidade;
    private System.Windows.Forms.Label lb_tamanho;

    #endregion
}