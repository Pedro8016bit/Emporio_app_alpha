﻿namespace Emporio_app;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
        Login_text = new System.Windows.Forms.Label();
        escreve_login = new System.Windows.Forms.TextBox();
        senha_text = new System.Windows.Forms.Label();
        escreve_senha = new System.Windows.Forms.TextBox();
        btn_Acesso = new System.Windows.Forms.Button();
        btn_cad = new System.Windows.Forms.Button();
        pictureBox1 = new System.Windows.Forms.PictureBox();
        pictureBox2 = new System.Windows.Forms.PictureBox();
        pictureBox3 = new System.Windows.Forms.PictureBox();
        pictureBox4 = new System.Windows.Forms.PictureBox();
        pictureBox5 = new System.Windows.Forms.PictureBox();
        pictureBox6 = new System.Windows.Forms.PictureBox();
        pictureBox7 = new System.Windows.Forms.PictureBox();
        ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
        SuspendLayout();
        // 
        // Login_text
        // 
        Login_text.Location = new System.Drawing.Point(510, 203);
        Login_text.Name = "Login_text";
        Login_text.Size = new System.Drawing.Size(38, 18);
        Login_text.TabIndex = 0;
        Login_text.Text = "Login";
        Login_text.Click += Login_text_Click;
        // 
        // escreve_login
        // 
        escreve_login.BackColor = System.Drawing.Color.Silver;
        escreve_login.BorderStyle = System.Windows.Forms.BorderStyle.None;
        escreve_login.Location = new System.Drawing.Point(510, 224);
        escreve_login.Name = "escreve_login";
        escreve_login.Size = new System.Drawing.Size(100, 16);
        escreve_login.TabIndex = 1;
        escreve_login.TextChanged += escreve_login_TextChanged;
        // 
        // senha_text
        // 
        senha_text.Location = new System.Drawing.Point(510, 243);
        senha_text.Name = "senha_text";
        senha_text.Size = new System.Drawing.Size(48, 17);
        senha_text.TabIndex = 2;
        senha_text.Text = "Senha";
        senha_text.Click += senha_text_Click;
        // 
        // escreve_senha
        // 
        escreve_senha.BackColor = System.Drawing.Color.Silver;
        escreve_senha.BorderStyle = System.Windows.Forms.BorderStyle.None;
        escreve_senha.Location = new System.Drawing.Point(510, 263);
        escreve_senha.Name = "escreve_senha";
        escreve_senha.Size = new System.Drawing.Size(100, 16);
        escreve_senha.TabIndex = 3;
        escreve_senha.TextChanged += escreve_senha_TextChanged;
        // 
        // btn_Acesso
        // 
        btn_Acesso.Cursor = System.Windows.Forms.Cursors.Default;
        btn_Acesso.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        btn_Acesso.Location = new System.Drawing.Point(478, 285);
        btn_Acesso.Name = "btn_Acesso";
        btn_Acesso.Size = new System.Drawing.Size(169, 23);
        btn_Acesso.TabIndex = 4;
        btn_Acesso.Text = "Acessar";
        btn_Acesso.UseVisualStyleBackColor = true;
        btn_Acesso.Click += btn_Acesso_Click;
        // 
        // btn_cad
        // 
        btn_cad.Cursor = System.Windows.Forms.Cursors.Default;
        btn_cad.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        btn_cad.Location = new System.Drawing.Point(478, 328);
        btn_cad.Name = "btn_cad";
        btn_cad.Size = new System.Drawing.Size(169, 23);
        btn_cad.TabIndex = 5;
        btn_cad.Text = "Cadastre-se";
        btn_cad.UseVisualStyleBackColor = true;
        btn_cad.Click += btn_cad_Click;
        // 
        // pictureBox1
        // 
        pictureBox1.Image = ((System.Drawing.Image)resources.GetObject("pictureBox1.Image"));
        pictureBox1.Location = new System.Drawing.Point(-8, 7);
        pictureBox1.MaximumSize = new System.Drawing.Size(1, 1);
        pictureBox1.Name = "pictureBox1";
        pictureBox1.Size = new System.Drawing.Size(1, 1);
        pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
        pictureBox1.TabIndex = 6;
        pictureBox1.TabStop = false;
        // 
        // pictureBox2
        // 
        pictureBox2.Image = ((System.Drawing.Image)resources.GetObject("pictureBox2.Image"));
        pictureBox2.Location = new System.Drawing.Point(-57, -5);
        pictureBox2.Name = "pictureBox2";
        pictureBox2.Size = new System.Drawing.Size(470, 480);
        pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox2.TabIndex = 7;
        pictureBox2.TabStop = false;
        // 
        // pictureBox3
        // 
        pictureBox3.Image = ((System.Drawing.Image)resources.GetObject("pictureBox3.Image"));
        pictureBox3.Location = new System.Drawing.Point(501, 130);
        pictureBox3.Name = "pictureBox3";
        pictureBox3.Size = new System.Drawing.Size(120, 70);
        pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox3.TabIndex = 8;
        pictureBox3.TabStop = false;
        // 
        // pictureBox4
        // 
        pictureBox4.Image = ((System.Drawing.Image)resources.GetObject("pictureBox4.Image"));
        pictureBox4.Location = new System.Drawing.Point(664, 425);
        pictureBox4.Name = "pictureBox4";
        pictureBox4.Size = new System.Drawing.Size(100, 50);
        pictureBox4.TabIndex = 9;
        pictureBox4.TabStop = false;
        // 
        // pictureBox5
        // 
        pictureBox5.Image = ((System.Drawing.Image)resources.GetObject("pictureBox5.Image"));
        pictureBox5.Location = new System.Drawing.Point(359, -5);
        pictureBox5.Name = "pictureBox5";
        pictureBox5.Size = new System.Drawing.Size(100, 50);
        pictureBox5.TabIndex = 10;
        pictureBox5.TabStop = false;
        // 
        // pictureBox6
        // 
        pictureBox6.Image = ((System.Drawing.Image)resources.GetObject("pictureBox6.Image"));
        pictureBox6.Location = new System.Drawing.Point(696, 14);
        pictureBox6.Name = "pictureBox6";
        pictureBox6.Size = new System.Drawing.Size(100, 50);
        pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox6.TabIndex = 11;
        pictureBox6.TabStop = false;
        // 
        // pictureBox7
        // 
        pictureBox7.Image = ((System.Drawing.Image)resources.GetObject("pictureBox7.Image"));
        pictureBox7.Location = new System.Drawing.Point(406, 441);
        pictureBox7.Name = "pictureBox7";
        pictureBox7.Size = new System.Drawing.Size(100, 50);
        pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
        pictureBox7.TabIndex = 12;
        pictureBox7.TabStop = false;
        // 
        // Form1
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        BackColor = System.Drawing.SystemColors.ControlLightLight;
        ClientSize = new System.Drawing.Size(756, 467);
        Controls.Add(pictureBox7);
        Controls.Add(pictureBox6);
        Controls.Add(pictureBox5);
        Controls.Add(pictureBox4);
        Controls.Add(pictureBox3);
        Controls.Add(pictureBox2);
        Controls.Add(pictureBox1);
        Controls.Add(btn_cad);
        Controls.Add(btn_Acesso);
        Controls.Add(escreve_senha);
        Controls.Add(senha_text);
        Controls.Add(escreve_login);
        Controls.Add(Login_text);
        Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)0));
        Text = "Emporio_System";
        ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
        ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.PictureBox pictureBox7;

    private System.Windows.Forms.PictureBox pictureBox6;

    private System.Windows.Forms.PictureBox pictureBox5;

    private System.Windows.Forms.PictureBox pictureBox4;

    private System.Windows.Forms.PictureBox pictureBox3;

    private System.Windows.Forms.PictureBox pictureBox2;

    private System.Windows.Forms.PictureBox pictureBox1;

    private System.Windows.Forms.Label senha_text;

    private System.Windows.Forms.TextBox escreve_senha;

    private System.Windows.Forms.TextBox escreve_login;
    private System.Windows.Forms.Label Login_text;

    private System.Windows.Forms.Button btn_Acesso;

    private System.Windows.Forms.Button btn_cad;

    private System.Windows.Forms.Label Login_TelaMenu;
    private System.Windows.Forms.TextBox textBox2;

    #endregion
}