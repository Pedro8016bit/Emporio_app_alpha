namespace Emporio_app;

public partial class Historico__de_vendas : Form
{
    public Historico__de_vendas()
    {
        InitializeComponent();
    }
}