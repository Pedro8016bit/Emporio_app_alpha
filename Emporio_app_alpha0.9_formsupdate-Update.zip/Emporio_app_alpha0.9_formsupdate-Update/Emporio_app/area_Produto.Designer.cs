using System.ComponentModel;

namespace Emporio_app;

partial class area_Produto
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(area_Produto));
        btn_Exclui_item = new System.Windows.Forms.Button();
        btn_Editar_item = new System.Windows.Forms.Button();
        btn_Cadastrar_item = new System.Windows.Forms.Button();
        txb_Name_item = new System.Windows.Forms.TextBox();
        Nome_Label = new System.Windows.Forms.Label();
        Preço_label = new System.Windows.Forms.Label();
        nUD_Preço_item = new System.Windows.Forms.NumericUpDown();
        nUD_Tamanho_item = new System.Windows.Forms.NumericUpDown();
        nUD_Quantidade_item = new System.Windows.Forms.NumericUpDown();
        Tamanho_item = new System.Windows.Forms.Label();
        Quantidade_item = new System.Windows.Forms.Label();
        listView1 = new System.Windows.Forms.ListView();
        id = new System.Windows.Forms.ColumnHeader();
        nome = new System.Windows.Forms.ColumnHeader();
        preco = new System.Windows.Forms.ColumnHeader();
        tamanho = new System.Windows.Forms.ColumnHeader();
        quantidade = new System.Windows.Forms.ColumnHeader();
        label1 = new System.Windows.Forms.Label();
        textBox2 = new System.Windows.Forms.TextBox();
        btn_Pesquisar_item = new System.Windows.Forms.Button();
        btn_Home = new System.Windows.Forms.Button();
        ((System.ComponentModel.ISupportInitialize)nUD_Preço_item).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nUD_Tamanho_item).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nUD_Quantidade_item).BeginInit();
        SuspendLayout();
        // 
        // btn_Exclui_item
        // 
        btn_Exclui_item.Location = new System.Drawing.Point(208, 418);
        btn_Exclui_item.Name = "btn_Exclui_item";
        btn_Exclui_item.Size = new System.Drawing.Size(132, 23);
        btn_Exclui_item.TabIndex = 0;
        btn_Exclui_item.Text = "Excluir";
        btn_Exclui_item.UseVisualStyleBackColor = true;
        btn_Exclui_item.Click += btn_Exclui_item_Click;
        // 
        // btn_Editar_item
        // 
        btn_Editar_item.Location = new System.Drawing.Point(490, 418);
        btn_Editar_item.Name = "btn_Editar_item";
        btn_Editar_item.Size = new System.Drawing.Size(132, 23);
        btn_Editar_item.TabIndex = 1;
        btn_Editar_item.Text = "Editar";
        btn_Editar_item.UseVisualStyleBackColor = true;
        btn_Editar_item.Click += btn_Editar_item_Click;
        // 
        // btn_Cadastrar_item
        // 
        btn_Cadastrar_item.Location = new System.Drawing.Point(623, 374);
        btn_Cadastrar_item.Name = "btn_Cadastrar_item";
        btn_Cadastrar_item.Size = new System.Drawing.Size(105, 23);
        btn_Cadastrar_item.TabIndex = 2;
        btn_Cadastrar_item.Text = "Cadastrar";
        btn_Cadastrar_item.UseVisualStyleBackColor = true;
        btn_Cadastrar_item.Click += btn_Cadastrar_item_Click;
        // 
        // txb_Name_item
        // 
        txb_Name_item.Location = new System.Drawing.Point(78, 374);
        txb_Name_item.Name = "txb_Name_item";
        txb_Name_item.Size = new System.Drawing.Size(100, 23);
        txb_Name_item.TabIndex = 3;
        // 
        // Nome_Label
        // 
        Nome_Label.Location = new System.Drawing.Point(78, 358);
        Nome_Label.Name = "Nome_Label";
        Nome_Label.Size = new System.Drawing.Size(100, 13);
        Nome_Label.TabIndex = 4;
        Nome_Label.Text = "Nome:";
        // 
        // Preço_label
        // 
        Preço_label.Location = new System.Drawing.Point(221, 358);
        Preço_label.Name = "Preço_label";
        Preço_label.Size = new System.Drawing.Size(88, 13);
        Preço_label.TabIndex = 5;
        Preço_label.Text = "Preço:";
        // 
        // nUD_Preço_item
        // 
        nUD_Preço_item.Location = new System.Drawing.Point(220, 374);
        nUD_Preço_item.Name = "nUD_Preço_item";
        nUD_Preço_item.Size = new System.Drawing.Size(89, 23);
        nUD_Preço_item.TabIndex = 6;
        // 
        // nUD_Tamanho_item
        // 
        nUD_Tamanho_item.Location = new System.Drawing.Point(354, 374);
        nUD_Tamanho_item.Name = "nUD_Tamanho_item";
        nUD_Tamanho_item.Size = new System.Drawing.Size(89, 23);
        nUD_Tamanho_item.TabIndex = 7;
        // 
        // nUD_Quantidade_item
        // 
        nUD_Quantidade_item.Location = new System.Drawing.Point(490, 374);
        nUD_Quantidade_item.Name = "nUD_Quantidade_item";
        nUD_Quantidade_item.Size = new System.Drawing.Size(89, 23);
        nUD_Quantidade_item.TabIndex = 8;
        // 
        // Tamanho_item
        // 
        Tamanho_item.Location = new System.Drawing.Point(355, 358);
        Tamanho_item.Name = "Tamanho_item";
        Tamanho_item.Size = new System.Drawing.Size(88, 13);
        Tamanho_item.TabIndex = 9;
        Tamanho_item.Text = "Tamanho:";
        // 
        // Quantidade_item
        // 
        Quantidade_item.Location = new System.Drawing.Point(490, 358);
        Quantidade_item.Name = "Quantidade_item";
        Quantidade_item.Size = new System.Drawing.Size(88, 13);
        Quantidade_item.TabIndex = 10;
        Quantidade_item.Text = "Quantidade:";
        // 
        // listView1
        // 
        listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] { id, nome, preco, tamanho, quantidade });
        listView1.HoverSelection = true;
        listView1.Location = new System.Drawing.Point(78, 77);
        listView1.MultiSelect = false;
        listView1.Name = "listView1";
        listView1.Size = new System.Drawing.Size(650, 259);
        listView1.TabIndex = 11;
        listView1.UseCompatibleStateImageBehavior = false;
        listView1.View = System.Windows.Forms.View.Details;
        // 
        // id
        // 
        id.Name = "id";
        id.Text = "id";
        // 
        // nome
        // 
        nome.Name = "nome";
        nome.Text = "Nome";
        // 
        // preco
        // 
        preco.DisplayIndex = 4;
        preco.Name = "preco";
        preco.Text = "Proço";
        preco.Width = 410;
        // 
        // tamanho
        // 
        tamanho.Name = "tamanho";
        tamanho.Text = "Tamanho";
        tamanho.Width = 153;
        // 
        // quantidade
        // 
        quantidade.DisplayIndex = 2;
        quantidade.Name = "quantidade";
        quantidade.Text = "Quantidade";
        quantidade.Width = 89;
        // 
        // label1
        // 
        label1.Location = new System.Drawing.Point(490, 19);
        label1.Name = "label1";
        label1.Size = new System.Drawing.Size(100, 23);
        label1.TabIndex = 12;
        label1.Text = "ID:";
        // 
        // textBox2
        // 
        textBox2.Location = new System.Drawing.Point(511, 19);
        textBox2.Name = "textBox2";
        textBox2.Size = new System.Drawing.Size(100, 23);
        textBox2.TabIndex = 13;
        // 
        // btn_Pesquisar_item
        // 
        btn_Pesquisar_item.Location = new System.Drawing.Point(617, 19);
        btn_Pesquisar_item.Name = "btn_Pesquisar_item";
        btn_Pesquisar_item.Size = new System.Drawing.Size(111, 23);
        btn_Pesquisar_item.TabIndex = 14;
        btn_Pesquisar_item.Text = "Pesquisar";
        btn_Pesquisar_item.UseVisualStyleBackColor = true;
        btn_Pesquisar_item.Click += btn_Pesquisar_item_Click;
        // 
        // btn_Home
        // 
        btn_Home.BackgroundImage = ((System.Drawing.Image)resources.GetObject("btn_Home.BackgroundImage"));
        btn_Home.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
        btn_Home.Location = new System.Drawing.Point(30, 19);
        btn_Home.Name = "btn_Home";
        btn_Home.Size = new System.Drawing.Size(27, 23);
        btn_Home.TabIndex = 15;
        btn_Home.UseVisualStyleBackColor = true;
        btn_Home.Click += btn_Home_Click;
        // 
        // area_Produto
        // 
        AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
        AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        ClientSize = new System.Drawing.Size(800, 450);
        Controls.Add(btn_Home);
        Controls.Add(btn_Pesquisar_item);
        Controls.Add(textBox2);
        Controls.Add(label1);
        Controls.Add(listView1);
        Controls.Add(Quantidade_item);
        Controls.Add(Tamanho_item);
        Controls.Add(nUD_Quantidade_item);
        Controls.Add(nUD_Tamanho_item);
        Controls.Add(nUD_Preço_item);
        Controls.Add(Preço_label);
        Controls.Add(Nome_Label);
        Controls.Add(txb_Name_item);
        Controls.Add(btn_Cadastrar_item);
        Controls.Add(btn_Editar_item);
        Controls.Add(btn_Exclui_item);
        Text = "area_Produto";
        ((System.ComponentModel.ISupportInitialize)nUD_Preço_item).EndInit();
        ((System.ComponentModel.ISupportInitialize)nUD_Tamanho_item).EndInit();
        ((System.ComponentModel.ISupportInitialize)nUD_Quantidade_item).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private System.Windows.Forms.ColumnHeader id;
    private System.Windows.Forms.ColumnHeader nome;
    private System.Windows.Forms.ColumnHeader quantidade;
    private System.Windows.Forms.ColumnHeader tamanho;
    private System.Windows.Forms.ColumnHeader preco;

    private System.Windows.Forms.Label Quantidade_item;

    private System.Windows.Forms.Button btn_Home;

    private System.Windows.Forms.NumericUpDown nUD_Preço_item;
    private System.Windows.Forms.NumericUpDown nUD_Tamanho_item;
    private System.Windows.Forms.NumericUpDown nUD_Quantidade_item;
    private System.Windows.Forms.Label Nome_Label;
    private System.Windows.Forms.Label Tamanho_item;
    private System.Windows.Forms.ListView listView1;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.Button btn_Pesquisar_item;

    private System.Windows.Forms.Label Preço_label;

    private System.Windows.Forms.Button btn_Exclui_item;
    private System.Windows.Forms.Button btn_Editar_item;
    private System.Windows.Forms.Button btn_Cadastrar_item;
    private System.Windows.Forms.TextBox txb_Name_item;
    private System.Windows.Forms.Label label1;

    #endregion
}