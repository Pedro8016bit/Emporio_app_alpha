﻿namespace Emporio_app;

public partial class Form2 : Form
{
    public Form2()
    {
        InitializeComponent();
    }

    public partial class FormRegistrarVenda : Form
    {


      

        private void label1_Click(object sender, EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            throw new System.NotImplementedException();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            throw new System.NotImplementedException();
        }


        private void Form2_Load(object sender, EventArgs e)
        {
            throw new System.NotImplementedException();
        }
    }

    private void btnVoltar_Click_1(object sender, EventArgs e)
    {
        Form1 primeiroFormulario = new Form1();
        primeiroFormulario.Show();
        this.Close();
    }

    private void Form2_Load(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void button2_Click(object sender, EventArgs e)
    {
        area_Produto areaProduto = new area_Produto();
        areaProduto.Show();
        this.Close();
    }
}
