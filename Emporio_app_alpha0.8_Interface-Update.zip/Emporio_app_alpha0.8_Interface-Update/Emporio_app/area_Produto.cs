namespace Emporio_app;

public partial class area_Produto : Form
{
    public area_Produto()
    {
        InitializeComponent();
    }

    private void btn_Home_Click(object sender, EventArgs e)
    {
        Form2 tela_menu = new Form2();
        tela_menu.Show();
        this.Close();
    }

    private void textBox2_TextChanged(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void btn_Pesquisar_item_Click(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void listView1_SelectedIndexChanged(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void txb_Name_item_TextChanged(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void nUD_Preço_item_ValueChanged(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void nUD_Tamanho_item_ValueChanged(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void nUD_Quantidade_item_ValueChanged(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void btn_Cadastrar_item_Click(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void btn_Exclui_item_Click(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void btn_Editar_item_Click(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void Quantidade_item_Click(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void label1_Click(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }

    private void area_Produto_Load(object sender, EventArgs e)
    {
        throw new System.NotImplementedException();
    }
}